#include "bitfields.h"
#include <assert.h>

int getBit(int bn,unsigned long val) {

  assert((63 >= bn) && (bn >= 0));

  if (((val>>bn) &1) == 1)
    {
      return 1;
    }
 
  return 0; 
  
 
}

void setBit(int bn,int new,unsigned long *val) {
  assert( (bn >=  0) && (bn <= 63));
    if(new)
      {
	
	unsigned long bruh = 1L;
	  bruh =  bruh << bn;
	  *val = *val | bruh;
       }
    else
      {
	unsigned long heh = 1L;
	heh = heh << bn;
	heh = ~heh;
	*val = *val & heh;
      }
  

}

long getBitFld(int bs,int len,unsigned long val) {
  assert((bs >=  0)  && (bs <= 63));
  assert((len <= (bs+1)) && (len > 0));

  unsigned long bruh3 = 0L;
  bruh3 = getBitFldU(bs, len, val);
  unsigned long bruh4 = 0L;
  bruh4 = bruh3 >> (len-1);

  if((bruh4 &1) == 1)
    {
      unsigned long heh2 = ~0L;
      heh2 = heh2 >> (len );
      heh2 = heh2 << (len );
      bruh3 = bruh3 | heh2;
    }

  return bruh3;
      

}
unsigned long getBitFldU(int bs,int len,unsigned long val) {

  assert( (bs >=  0) && (bs<= 63));
  assert((len <= (bs+1)) && (len > 0));

   unsigned long mask = ~0L;
   mask = mask >> (64 - len);

   mask = mask << (bs - len + 1);

   unsigned long bruh2 = 0L;
   bruh2  = val & mask;
   
   bruh2 = bruh2 >> (bs -len + 1);
   
   return bruh2;
}

void setBitFld(int bs,int len,unsigned long new,unsigned long *val) {

  // assert( (bs >=  0) && (bs<= 63));
  // assert((len <= (bs+1)) && (len > 0));

  unsigned long mask = ~0L;
  mask = mask >> (64 - len);
  new = new & mask;
  new = new << (bs - len + 1);
  mask = mask << (bs - len +1);
  *val = *val & ~mask;

  *val = *val | new;
  
  
  
}
